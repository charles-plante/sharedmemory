package com.example.appsharedmemory;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.Set;
import java.util.UUID;


public class Receiver extends Fragment {


    /*---- Variables ----*/

    //bluetooth adapter
    BluetoothAdapter BTadapter;

    ImageView BTimage_r;
    TextView showPaired;
    Button btnStartRecovery, btnStopRecovery;

    private BluetoothServerSocket serverSocket;

    // Name for SDP record when creating server socket
    private static final String NAME = "SharedMemory";
    // UUID
    private static final UUID MY_UUID = UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");


    /*---- Constructeur ---*/
    public Receiver() {}


    /*---- Fonction Oncreate ----*/
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_receiver, container, false);


        BTadapter = BluetoothAdapter.getDefaultAdapter();

        BTimage_r = v.findViewById(R.id.BTimage_receiver);
        showPaired = v.findViewById(R.id.showPaired);
        btnStartRecovery = v.findViewById(R.id.btnStartReceive);
        btnStopRecovery = v.findViewById(R.id.btnStopReceive);

        //feedback sur le bluetooth
        if (BTadapter.isEnabled()) {
            BTimage_r.setImageResource(R.drawable.bluetooth_on);
        } else {
            BTimage_r.setImageResource(R.drawable.bluetooth_off);
        }


        /*---- Fonction Start Data Recovery ----*/
        btnStartRecovery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                /*---- MET TON THREAD DE RECEIVE / SERVEUR ----*/


                //set up bluetooth
                setUpBluetooth();

                //delay 1s
                try {
                    Thread.sleep(3000);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                //on affiche dans showPaired les appareils appairés
                showPaired.setText("\n   Paired devices : \n\n");
                Set<BluetoothDevice> devices = BTadapter.getBondedDevices();
                for (BluetoothDevice device : devices) {
                    showPaired.append("   ->  " + device.getName() + ",   " + device + "\n");
                }



                /*
                //part 1

                BluetoothServerSocket tmp = null;
                try {
                    Log.i("DIM", "ouverture serveur");
                    tmp = BTadapter.listenUsingRfcommWithServiceRecord(NAME, MY_UUID);
                } catch (IOException e) {
                    Log.i("DIM", "Socket's listen() method failed");
                }
                serverSocket = tmp;


                //part2
                BluetoothSocket socket2 = null;

                while (true) {
                    try {
                        Log.i("DIM", "serveur attend connexion");
                        socket2 = serverSocket.accept();
                    } catch (IOException e) {
                        Log.i("DIM", "Socket's accept() method failed");
                        break;
                    }

                    if (socket2 != null) {
                        // A connection was accepted. Perform work associated with
                        // the connection in a separate thread.
                        try {
                            serverSocket.close();
                        }catch (IOException e) {
                            Log.i("DIM", "Socket's accept() method failed");
                            break;
                        }

                        break;
                    }
                }

                 */


            }
        });



        /*---- Fonction Stop Data Recovery ----*/
        btnStopRecovery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                offBluetooth();

                //on efface le texte du textview
                showPaired.setText("");
            }
        });

        return v;
    }



    /*---- Fonction de set up du bluetooth ----*/
    public void setUpBluetooth(){

        //si BTadapter est null, alors le bluetooth n'est pas supporté par l'appareil
        if (BTadapter == null)
        {
            //Toast.makeText(this,"Bluetooth is not available", Toast.LENGTH_SHORT).show();
        }

        //si le bluetooth est désactivé, on l'active
        else if(!BTadapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1);

            // feedback image bluetooth actif
            BTimage_r.setImageResource(R.drawable.bluetooth_on);
        }
    }


    /*---- Fonction off du bluetooth ----*/
    public void offBluetooth() {

        //si le bluetooth est activé alors on le désactive
        if (BTadapter.isEnabled()) {
            BTadapter.disable();

            // feedback bluetooth off
            BTimage_r.setImageResource(R.drawable.bluetooth_off);
        }
    }


    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }
}
