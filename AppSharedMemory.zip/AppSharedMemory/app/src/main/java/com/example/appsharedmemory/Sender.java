package com.example.appsharedmemory;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.util.Set;
import java.util.UUID;


public class Sender extends Fragment {

    /*---- Variables ----*/

    // IL FAUDRAIT QUE LE BLUETOOTH ADAPTER SOIT PARTAGE POUR LA CLASSE RECEIVER ET SENDER
    //BluetoothAdapter BTadapter;


    // UUID DOIT ETRE COMMUN POUR LES CLASSES RECEIVER ET SENDER AUSSI
    //private static final UUID MY_UUID = UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");

    ImageView BTimage_s;
    EditText receiverAddress;
    Boolean stateSending = false;
    String data = "testestest";

    private BluetoothSocket socket;
    Button btnStartSending, btnStopSending;



    /*---- Constructeur ----*/
    public Sender() {}



    /*---- Fonction Oncreate ----*/
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_sender, container, false);


        BTimage_s = v.findViewById(R.id.BTimage_sender);

        //adresse de l'appareil receiver
        receiverAddress = v.findViewById(R.id.addressReceivertxt);

        btnStartSending = v.findViewById(R.id.btnStartSend);
        btnStopSending = v.findViewById(R.id.btnStopSend);


        //BTadapter = BluetoothAdapter.getDefaultAdapter();

        /*
        //feedback sur le bluetooth
        if (BTadapter.isEnabled()) {
            BTimage_r.setImageResource(R.drawable.bluetooth_on);
        } else {
            BTimage_r.setImageResource(R.drawable.bluetooth_off);
        }
        */


        /*---- Fonction Start Data Sending ----*/
        btnStartSending.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                /*---- MET TON THREAD DE SEND / CLIENT ----*/


               /* //on met l'etat d'envoi à 1
                stateSending = true;

                //flag de l'envoi des datas à 0
                boolean dataFlag = false;

                // set up bluetooth
                setUpBluetooth();


                //on résupère les paired devices
                Set<BluetoothDevice> devices = BTadapter.getBondedDevices();

                // on fait le tour de la liste et on get l'appareil dont l'adresse correspond
                for (BluetoothDevice btd : devices) {
                    if (btd.getAddress().equals(receiverAddress.getText().toString())) {

                        connexionSender(btd);


                        try {
                            Log.i("DIM", "connexion au device");
                            socket.connect();
                        }
                        catch (IOException connectException) {
                            try {
                                socket.close();
                            } catch (IOException closeException) {
                                Log.i("DIM", "Could not close the client socket", closeException);
                            }
                        }


                        Log.i("DIM", "le device est connecte");*/




                        /*---- Fonction ENVOI DE DATAS ----*/

                        /* if (data != null){
                            OutputStream opt = socket.getOutputStream();
                            opt.write(data.getBytes());
                            dataFlag = true;
                            Log.i("DIM","message envoye");
                            socket.close();
                            break;
                        }
                        // connexion device address = addressReceiver
                        // send data
                        // disconnect when finished

                        break;


                    }
                }*/
            }
        });



        /*---- Fonction Stop Data Sending ----*/
        btnStopSending.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });



        return v;
    }



    /*---- Fonction de set up du bluetooth ----*/
    /*public void setUpBluetooth(){

        //si BTadapter est null, alors le bluetooth n'est pas supporté par l'appareil
        if (BTadapter == null)
        {
            //Toast.makeText(this,"Bluetooth is not available", Toast.LENGTH_SHORT).show();
        }

        //si le bluetooth est désactivé, on l'active
        else if(!BTadapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1);

            // feedback image bluetooth actif
            BTimage_r.setImageResource(R.drawable.bluetooth_on);
        }
    }*/



    /*---- Fonction connexion du sender ----*/
    /*public void connexionSender(BluetoothDevice btd) {
        BluetoothSocket tmp = null;
        try {

            Log.i("DIM", "connextion vers :");
            Log.i("DIM", btd.getName());

            tmp = btd.createRfcommSocketToServiceRecord(MY_UUID);
        } catch (IOException e) {
            Log.i("DIM", "Socket's create() method failed");
        }
        socket = tmp;
    }*/



    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }
}
