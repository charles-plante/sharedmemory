package com.example.appsharedmemory;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import com.example.appsharedmemory.Receiver;
import com.example.appsharedmemory.Sender;

public class PagerAdapter extends FragmentStatePagerAdapter {

    int nbPages;

    public PagerAdapter(FragmentManager fm, int NumberOfTabs)
    {
        super(fm);
        this.nbPages = NumberOfTabs;
    }




    @Override
    public Fragment getItem(int position) {
        switch(position)
        {
            case 0 :
                Receiver receiver = new Receiver();
                return receiver;

            case 1 :
                Sender sender = new Sender();
                return sender;

            default :
                return null;
        }




    }

    @Override
    public int getCount() {
        return nbPages;
    }
}
